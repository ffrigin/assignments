package assignments;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class TCPServer {
    private static final long InitialKey = 123456789L;

    public static void main(String[] args) {
        // Port number 
        int portNumber = 26900;

        try (ServerSocket serverSocket = new ServerSocket(portNumber)) {
            // server start message
            System.out.println("TCP Server: Listening on port " + portNumber + "...");

            // Main loop to accept client connections indefinitely
            while (true) {
                try (Socket clientSocket = serverSocket.accept(); // Accept a client connection
                     DataInputStream in = new DataInputStream(clientSocket.getInputStream()); // Prepare to read data from the client
                     DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream())) { // Prepare to send data to the client

                    // Let me know when server connected
                    System.out.println("TCP Server: Client connected from " + clientSocket.getInetAddress().getHostAddress() + ".");
                    // Reset the encryption key to its initial value for each new client connection
                    long key = InitialKey;

                    // Inner loop to process messages from the connected client
                    while (true) {
                        // Read the length of the incoming message
                        int length = in.readInt();
                        // Special case: if length is -1, it's a signal to reset the encryption key
                        if (length == -1) {
                            System.out.println("TCP Server: End of message batch detected.");
                            key = InitialKey; // Reset the key for the next batch of messages
                            continue;
                        }

                        // If length is 0 or less, it indicates the end of the client session
                        if (length <= 0) break;

                        // Read the encrypted message from the client
                        byte[] messageBytes = new byte[length];
                        in.readFully(messageBytes);
                        // Decrypt the received message using the current key
                        byte[] decryptedMessage = XOREncryptionService.encryptDecrypt(messageBytes, key);
                        // Update the encryption key for the next message
                        key = XOREncryptionService.xorShift(key);

                        // Validate the decrypted message to ensure it meets expected criteria
                        boolean isValid = validateDecryptedMessage(decryptedMessage);
                        // Log the result of the message validation
                        System.out.println("TCP Server: Message validation: " + (isValid ? "Success" : "Failed"));

                        // If the message is invalid, log the error and break the loop to end the session
                        if (!isValid) {
                            System.out.println("TCP Server: Invalid message received, closing connection.");
                            break;
                        }

                        // Echo back the original (encrypted) message to the client as an acknowledgment
                        out.writeInt(messageBytes.length);
                        out.write(messageBytes);
                    }

                    // Log the end of the session with the current client
                    System.out.println("TCP Server: Session with client ended.");
                } catch (IOException e) {
                    // Handle exceptions related to client communication
                    System.out.println("TCP Server: Connection error - " + e.getMessage());
                }
            }
        } catch (IOException e) {
            // Handle exceptions related to server socket initialization
            System.out.println("TCP Server: Server error - " + e.getMessage());
        }
    }

    // Method to validate the decrypted message against expected criteria
    private static boolean validateDecryptedMessage(byte[] decryptedMessage) {
        // Check each byte of the decrypted message
        for (int i = 0; i < decryptedMessage.length; i++) {
            // If any byte does not match the expected pattern, return false
            if ((byte) (i % 128) != decryptedMessage[i]) {
                return false;
            }
        }
        // If all bytes match the expected pattern, the message is valid
        return true;
    }
}
