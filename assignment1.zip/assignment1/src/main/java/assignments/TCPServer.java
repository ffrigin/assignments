package assignments;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class TCPServer {
    private static final long InitialKey = 123456789L;

    public static void main(String[] args) {
        int portNumber = 26900;

        try (ServerSocket serverSocket = new ServerSocket(portNumber)) {
            System.out.println("TCP Server: Listening on port " + portNumber + "...");

            while (true) {
                try (Socket clientSocket = serverSocket.accept();
                     DataInputStream in = new DataInputStream(clientSocket.getInputStream());
                     DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream())) {

                    System.out.println("TCP Server: Client connected from " + clientSocket.getInetAddress().getHostAddress() + ".");
                    long key = InitialKey;

                    while (true) {
                        int length;
                        try {
                            length = in.readInt();
                        } catch (EOFException e) {
                            System.out.println("TCP Server: Client disconnected.");
                            break;
                        }

                        if (length == -1) {
                            System.out.println("TCP Server: End of message batch detected.");
                            key = InitialKey;
                            continue;
                        }

                        if (length <= 0) break;

                        byte[] messageBytes = new byte[length];
                        in.readFully(messageBytes);
                        byte[] decryptedMessage = XOREncryptionService.encryptDecrypt(messageBytes, key);
                        key = XOREncryptionService.xorShift(key);

                        boolean isValid = validateDecryptedMessage(decryptedMessage);
                        System.out.println("TCP Server: Message validation: " + (isValid ? "Success" : "Failed"));

                        if (!isValid) {
                            System.out.println("TCP Server: Invalid message received, closing connection.");
                            break;
                        }

                        out.writeInt(messageBytes.length);
                        out.write(messageBytes);
                        out.flush();
                    }

                } catch (IOException e) {
                    System.out.println("TCP Server: Error handling client connection - " + e.getMessage());
                }
                System.out.println("TCP Server: Session with client ended.");
            }
        } catch (IOException e) {
            System.out.println("TCP Server: Could not start server on port " + portNumber + " - " + e.getMessage());
        }
    }

    private static boolean validateDecryptedMessage(byte[] decryptedMessage) {
        for (int i = 0; i < decryptedMessage.length; i++) {
            if ((byte) (i % 128) != decryptedMessage[i]) {
                return false;
            }
        }
        return true;
    }
}
