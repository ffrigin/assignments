package assignments;

import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class UDPServer {
    private static final long InitialKey = 123456789L;
    private static final String TERMINATION_MESSAGE = "END";

    public static void main(String[] args) {
        int portNumber = 26900;

        try (DatagramSocket socket = new DatagramSocket(portNumber)) {
            System.out.println("UDP Server listening on port " + portNumber);

            boolean running = true;
            while (running) {
                byte[] receiveBuffer = new byte[2048];
                DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                socket.receive(receivePacket);
                
                byte[] receivedData = new byte[receivePacket.getLength()];
                System.arraycopy(receivePacket.getData(), receivePacket.getOffset(), receivedData, 0, receivePacket.getLength());

                long key = InitialKey; // Simulate key adjustment if needed
                byte[] decryptedData = XOREncryptionService.encryptDecrypt(receivedData, key);

                // Check for termination message
                String receivedString = new String(decryptedData).trim();
                if (TERMINATION_MESSAGE.equals(receivedString)) {
                    running = false;
                    System.out.println("Termination signal received. Shutting down server.");
                    break;
                }

                if (validateDecryptedMessage(decryptedData)) {
                    System.out.println("Message validation: Success");
                    // Send ACK back to the client
                    byte[] ack = "OK".getBytes();
                    DatagramPacket ackPacket = new DatagramPacket(ack, ack.length, receivePacket.getAddress(), receivePacket.getPort());
                    socket.send(ackPacket);
                } else {
                    System.out.println("Message validation: Failed");
                }
            }
        } catch (Exception e) {
            System.out.println("Server exception: " + e.getMessage());
        }
    }

    private static boolean validateDecryptedMessage(byte[] message) {
        // Validation logic remains the same
        return true;
    }
}
