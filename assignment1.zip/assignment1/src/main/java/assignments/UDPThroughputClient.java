package assignments;

import java.io.IOException;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class UDPThroughputClient {
    private static final long InitialKey = 123456789L;
    private static final String EndMessage = "END";

    public static void main(String[] args) {
        String serverAddress = "localhost";
        int serverPort = 26900;

        // Create a new UDP socket
    try (DatagramSocket socket = new DatagramSocket()) {
        // Set a timeout for blocking receive calls
        socket.setSoTimeout(10000);
        // Resolve the hostname to an IP address
        InetAddress serverInetAddress = InetAddress.getByName(serverAddress);

        // Define message sizes and counts for testing
        int[][] specs = {
            {16384, 64}, 
            {4096, 256}, 
            {1024, 1024} 
        };

        // Iterate over each message size and count specification
        for (int[] spec : specs) {
            // Create a thread pool for concurrent message sending
            ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
            // Counter for acknowledged messages
            AtomicInteger ackCounter = new AtomicInteger(0);

            // Extract message count and size from the spec array
            int messageCount = spec[0];
            int messageSize = spec[1];
            // Generate a known message based on the size
            byte[] message = generateKnownMessage(messageSize);
            // Set the initial encryption key
            long key = InitialKey;

            // Start transmission and record the start time
            System.out.println("Starting transmission: " + messageCount + " messages of " + messageSize + " bytes.");
            long startTime = System.nanoTime();

            // Loop to send all messages
            for (int i = 0; i < messageCount; i++) {
                // Create a final copy of the current key for use in the thread
                final long threadKey = key;
                // Submit a task to the executor to send the message
                executor.submit(() -> {
                    try {
                        // Encrypt the message
                        byte[] encryptedMessage = XOREncryptionService.encryptDecrypt(message, threadKey);
                        // Create and send the datagram packet
                        DatagramPacket sendPacket = new DatagramPacket(encryptedMessage, encryptedMessage.length, serverInetAddress, serverPort);
                        socket.send(sendPacket);

                        // Wait for an acknowledgment packet
                        DatagramPacket ackPacket = new DatagramPacket(new byte[2], 2);
                        socket.receive(ackPacket);
                        // Increment the acknowledgment counter
                        ackCounter.incrementAndGet();
                    } catch (IOException e) {
                        // Print any errors during sending/receiving
                        System.err.println("Error sending/receiving acknowledgment: " + e.getMessage());
                    }
                });
                // Update the key for the next message
                key = XOREncryptionService.xorShift(key);
            }

            // Shut down the executor and wait for all tasks to complete
            executor.shutdown();
            try {
                // Wait for a maximum of 1 second for all tasks to finish
                while (!executor.awaitTermination(1, TimeUnit.SECONDS)) {
                    // If all messages are acknowledged, break the loop
                    if (ackCounter.get() == messageCount) {
                        break;
                    }
                }
            } catch (InterruptedException e) {
                // Handle thread interruption
                Thread.currentThread().interrupt();
            }

            // Record the end time and calculate the duration and throughput
            long endTime = System.nanoTime();
            double durationSeconds = (endTime - startTime) / 1_000_000_000.0;
            long totalBytes = (long) ackCounter.get() * messageSize;
            double throughput = (totalBytes * 8) / durationSeconds;

            // Print the throughput measurement
            System.out.println("Throughput for " + ackCounter.get() + " acknowledged messages of " + messageSize + " bytes: " + throughput + " bps");
        }

        // After all transmissions, send a termination signal to the server
        byte[] terminationSignal = EndMessage.getBytes();
        socket.send(new DatagramPacket(terminationSignal, terminationSignal.length, serverInetAddress, serverPort));
    } catch (Exception e) {
        // Catch and print any exceptions
        System.err.println("Client exception: " + e.getMessage());
    }
}

    private static byte[] generateKnownMessage(int size) {
        byte[] message = new byte[size];
        for (int i = 0; i < size; i++) {
            message[i] = (byte) (i % 128);
        }
        return message;
    }
}
