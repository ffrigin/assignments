package assignments;

import java.io.IOException;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class UDPThroughputClient {
    private static final long InitialKey = 123456789L;
    private static final String EndMessage = "END";

    public static void main(String[] args) {
        String serverAddress = "pi.cs.oswego.edu";
        int serverPort = 26900;

        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setSoTimeout(10000);
            InetAddress serverInetAddress = InetAddress.getByName(serverAddress);

            int[][] specs = {
                {16384, 64},
                {4096, 256},
                {1024, 1024}
            };

            for (int[] spec : specs) {
                ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
                AtomicInteger ackCounter = new AtomicInteger(0);

                int messageCount = spec[0];
                int messageSize = spec[1];
                byte[] message = generateKnownMessage(messageSize);
                long key = InitialKey;

                // Pre-allocate memory for encrypted messages
                byte[][] encryptedMessages = new byte[messageCount][messageSize];
                for (int i = 0; i < messageCount; i++) {
                    encryptedMessages[i] = XOREncryptionService.encryptDecrypt(message, key);
                    key = XOREncryptionService.xorShift(key); // Prepare all encrypted messages upfront
                }

                System.out.println("Starting transmission: " + messageCount + " messages of " + messageSize + " bytes.");
                long startTime = System.nanoTime();

                key = InitialKey; // Reset the key for sending messages
                for (int i = 0; i < messageCount; i++) {
                    final int index = i;
                    executor.submit(() -> {
                        try {
                            DatagramPacket sendPacket = new DatagramPacket(encryptedMessages[index], encryptedMessages[index].length, serverInetAddress, serverPort);
                            socket.send(sendPacket);

                            DatagramPacket ackPacket = new DatagramPacket(new byte[2], 2);
                            socket.receive(ackPacket);
                            ackCounter.incrementAndGet();
                        } catch (IOException e) {
                            System.err.println("Error sending/receiving acknowledgment: " + e.getMessage());
                        }
                    });
                    key = XOREncryptionService.xorShift(key); // Update the key for the next message
                }

                executor.shutdown();
                try {
                    while (!executor.awaitTermination(1, TimeUnit.SECONDS)) {
                        if (ackCounter.get() == messageCount) {
                            break;
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }

                long endTime = System.nanoTime();
                double durationSeconds = (endTime - startTime) / 1_000_000_000.0;
                long totalBytes = (long) ackCounter.get() * messageSize;
                double throughput = (totalBytes * 8) / durationSeconds;

                System.out.println("Throughput for " + ackCounter.get() + " acknowledged messages of " + messageSize + " bytes: " + throughput + " bps");
            }

            byte[] terminationSignal = EndMessage.getBytes();
            socket.send(new DatagramPacket(terminationSignal, terminationSignal.length, serverInetAddress, serverPort));
        } catch (Exception e) {
            System.err.println("Client exception: " + e.getMessage());
        }
    }

    private static byte[] generateKnownMessage(int size) {
        byte[] message = new byte[size];
        for (int i = 0; i < size; i++) {
            message[i] = (byte) (i % 128);
        }
        return message;
    }
}
