package assignments;

import java.io.*;
import java.net.Socket;
import java.util.Arrays;

public class TCPThroughputClient {
    
    private static final long InitialKey = 123456789L;

    public static void main(String[] args) {
        String serverAddress = "pi.cs.oswego.edu";
        int portNumber = 26900;

        try (Socket socket = new Socket(serverAddress, portNumber);
             DataOutputStream out = new DataOutputStream(socket.getOutputStream());
             DataInputStream in = new DataInputStream(socket.getInputStream())) {
             
            // Notify successful connection to the server
            System.out.println("TCP Client: Connected to server at " + serverAddress + ":" + portNumber);
            
            // Array defining message counts and sizes for throughput tests
            int[][] specs = {
                {16384, 64},   // 16,384 messages of 64 bytes
                {4096, 256},   // 4,096 messages of 256 bytes
                {1024, 1024}   // 1,024 messages of 1024 bytes
            };

            // Iterate over each spec for sending messages and measuring throughput
            for (int[] spec : specs) {
                int messageCount = spec[0];
                int messageSize = spec[1];
                byte[] message = generateKnownMessage(messageSize); // Generate a message of specified size
                long key = InitialKey; // Initialize encryption key
                
                long startTime = System.nanoTime(); // Start timing
                
                // Send specified number of messages, encrypted with the current key
                for (int i = 0; i < messageCount; i++) {
                    byte[] encryptedMessage = XOREncryptionService.encryptDecrypt(message, key);
                    out.writeInt(encryptedMessage.length); // Send message length
                    out.write(encryptedMessage); // Send encrypted message
                    key = XOREncryptionService.xorShift(key); // Update key for next message
                }

                out.writeInt(-1); // Signal end of message batch to server

                key = InitialKey; // Reset key for validating echoed messages
                // Validate echoed messages from server
                for (int i = 0; i < messageCount; i++) {
                    int length = in.readInt(); // Read echoed message length
                    if (length <= 0) break; // End loop if invalid length

                    byte[] echoMessage = new byte[length]; // Receive echoed message
                    in.readFully(echoMessage);
                    byte[] decryptedEchoMessage = XOREncryptionService.encryptDecrypt(echoMessage, key); // Decrypt echoed message
                    key = XOREncryptionService.xorShift(key); // Update key

                    // Validate decrypted echoed message matches original
                    if (!Arrays.equals(message, decryptedEchoMessage)) {
                        System.out.println("TCP Client: Validation Failed at message " + (i + 1));
                        break;
                    }
                }

                long endTime = System.nanoTime(); // End timing
                double durationSeconds = (endTime - startTime) / 1_000_000_000.0; // Calculate duration in seconds
                long totalBytes = (long) messageCount * messageSize; // Calculate total bytes sent
                long throughput = (long) ((totalBytes * 8) / durationSeconds); // Calculate throughput in bits per second

                // Log throughput for the current spec
                System.out.println("TCP Client: Throughput for " + messageCount + " messages of " + messageSize + " bytes: " + throughput + " bps");
            }

            // Notify completion of all transmissions
            System.out.println("TCP Client: Completed all transmissions.");
        } catch (IOException e) {
            // Handle any IO exceptions
            System.out.println("TCP Client: Error - " + e.getMessage());
        }
    }

    // Generate a known pattern message for testing
    private static byte[] generateKnownMessage(int size) {
        byte[] message = new byte[size];
        for (int i = 0; i < size; i++) {
            message[i] = (byte) (i % 128); // Fill with a repeating pattern to ensure predictability
        }
        return message;
    }
}
