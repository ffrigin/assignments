package assignments;

import java.io.*;
import java.net.Socket;
import java.util.Arrays;

public class TCPThroughputClient {
    
    private static final long InitialKey = 123456789L;

    public static void main(String[] args) {
        String serverAddress = "pi.cs.oswego.edu";
        int portNumber = 26900;

        try (Socket socket = new Socket(serverAddress, portNumber);
             DataOutputStream out = new DataOutputStream(socket.getOutputStream());
             DataInputStream in = new DataInputStream(socket.getInputStream())) {
             
            System.out.println("TCP Client: Connected to server at " + serverAddress + ":" + portNumber);
            
            int[][] specs = {
                {16384, 64},   // 16,384 messages of 64 bytes
                {4096, 256},   // 4,096 messages of 256 bytes
                {1024, 1024}   // 1,024 messages of 1024 bytes
            };

            for (int[] spec : specs) {
                int messageCount = spec[0];
                int messageSize = spec[1];
                byte[] message = generateKnownMessage(messageSize);
                long key = InitialKey;
                
                long startTime = System.nanoTime();
                
                for (int i = 0; i < messageCount; i++) {
                    byte[] encryptedMessage = XOREncryptionService.encryptDecrypt(message, key);
                    out.writeInt(encryptedMessage.length);
                    out.write(encryptedMessage);
                    key = XOREncryptionService.xorShift(key);
                }
                
                out.flush(); // Ensure all data is sent immediately
                
                out.writeInt(-1); // Signal end of message batch to server
                out.flush(); // Ensure the end signal is sent immediately

                key = InitialKey; // Reset key for validating echoed messages
                for (int i = 0; i < messageCount; i++) {
                    int length = in.readInt();
                    if (length <= 0) break;

                    byte[] echoMessage = new byte[length];
                    in.readFully(echoMessage);
                    byte[] decryptedEchoMessage = XOREncryptionService.encryptDecrypt(echoMessage, key);
                    key = XOREncryptionService.xorShift(key);

                    if (!Arrays.equals(message, decryptedEchoMessage)) {
                        System.out.println("TCP Client: Validation Failed at message " + (i + 1));
                        break;
                    }
                }

                long endTime = System.nanoTime();
                double durationSeconds = (endTime - startTime) / 1_000_000_000.0;
                long totalBytes = (long) messageCount * messageSize;
                long throughput = (long) ((totalBytes * 8) / durationSeconds);

                System.out.println("TCP Client: Throughput for " + messageCount + " messages of " + messageSize + " bytes: " + throughput + " bps");
            }

            System.out.println("TCP Client: Completed all transmissions.");
        } catch (IOException e) {
            System.out.println("TCP Client: Error - " + e.getMessage());
        }
    }

    private static byte[] generateKnownMessage(int size) {
        byte[] message = new byte[size];
        for (int i = 0; i < size; i++) {
            message[i] = (byte) (i % 128);
        }
        return message;
    }
}
