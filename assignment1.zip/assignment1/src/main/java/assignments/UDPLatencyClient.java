package assignments;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPLatencyClient {
   
    private static final long InitialKey = 123456789L;

    public static void main(String[] args) {
        String serverAddress = "localhost"; // change me
        int portNumber = 26900;

        try (DatagramSocket socket = new DatagramSocket()) {
            InetAddress serverInetAddress = InetAddress.getByName(serverAddress);

            // Send messages of various sizes
            for (int messageSize : new int[]{8, 64, 512}) {
                byte[] originalMessage = generateRandomMessage(messageSize);
                long key = InitialKey; // Reset key for each message
                byte[] encryptedMessage = XOREncryptionService.encryptDecrypt(originalMessage, key);
                // No need to update key after encryption if the server isn't echoing the message content back

                // Measure RTT
                long startTime = System.nanoTime();

                DatagramPacket sendPacket = new DatagramPacket(encryptedMessage, encryptedMessage.length, serverInetAddress, portNumber);
                socket.send(sendPacket);

                // Prepare to receive any acknowledgment
                byte[] ackBuffer = new byte[1024]; // Ensure buffer is large enough for the acknowledgment
                DatagramPacket ackPacket = new DatagramPacket(ackBuffer, ackBuffer.length);
                socket.receive(ackPacket); // Wait for acknowledgment

                long endTime = System.nanoTime();
                long rtt = (endTime - startTime) / 1_000_000; // RTT in milliseconds

                // Assuming any received packet is considered a valid acknowledgment
                System.out.println("Received acknowledgment for message size " + messageSize + " bytes, RTT: " + rtt + " ms");
            }

            // Send termination signal
            byte[] terminationSignal = "END".getBytes();
            DatagramPacket terminationPacket = new DatagramPacket(terminationSignal, terminationSignal.length, serverInetAddress, portNumber);
            socket.send(terminationPacket);
            System.out.println("Termination signal sent to the server.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static byte[] generateRandomMessage(int size) {
        byte[] message = new byte[size];
        for (int i = 0; i < size; i++) {
            message[i] = (byte) (i % 128);
        }
        return message;
    }
}
