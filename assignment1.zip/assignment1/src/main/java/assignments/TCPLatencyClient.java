package assignments;

import java.io.*;
import java.net.Socket;
import java.net.InetSocketAddress;
import java.util.Arrays;

public class TCPLatencyClient {
    private String host;
    private int port;
    private Socket socket;
    private DataOutputStream out;
    private DataInputStream in; 

    private long key = 123456789L;

    public static void main(String[] args) {
        try {
            // change host and port here
            TCPLatencyClient client = new TCPLatencyClient("pi.cs.oswego.edu", 26900);
            client.connect();
            client.measureRTTAndThroughput();
            client.close();
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    // Constructor to initialize the client with the server's host and port.
    public TCPLatencyClient(String host, int port) {
        this.host = host;
        this.port = port;
    }

    // Connects to the server and initializes the data streams.
    public void connect() throws IOException {
        socket = new Socket(); // Creates a new socket.
        socket.connect(new InetSocketAddress(host, port), 5000); // Connects to the server with a timeout.
        socket.setSoTimeout(10000); // Sets a read timeout for the socket.
        out = new DataOutputStream(socket.getOutputStream()); // Initializes the output stream.
        in = new DataInputStream(socket.getInputStream()); // Initializes the input stream.
    }

    // Measures RTT for messages of different sizes and prints the results.
    public void measureRTTAndThroughput() throws IOException {
        int[] messageSizes = {8, 64, 512}; // Define message sizes to test.
        for (int size : messageSizes) {
            byte[] message = generateRandomMessage(size); // Generate a message of the given size.
            long rtt = measureRTT(message); // Measure the round-trip time.
            System.out.println("RTT for " + size + " bytes: " + rtt + " ms"); // Print the RTT.
        }
    }

    // Generates a message of a given size with a predictable pattern.
    private byte[] generateRandomMessage(int size) {
        byte[] message = new byte[size];
        for (int i = 0; i < size; i++) {
            message[i] = (byte) (i % 128); // Fill the message with a repeating pattern.
        }
        return message;
    }

    // Measures the round-trip time for a single message.
    public long measureRTT(byte[] originalMessage) throws IOException {
        long startTime = System.nanoTime(); // Record the start time.
        byte[] encryptedMessage = XOREncryptionService.encryptDecrypt(originalMessage, key); // Encrypt the message.
        out.writeInt(encryptedMessage.length); // Send the encrypted message length.
        out.write(encryptedMessage); // Send the encrypted message.
        out.flush(); // Ensure the message is sent immediately.
        key = XOREncryptionService.xorShift(key); // Update the encryption key.
        
        int length = in.readInt(); // Read the length of the echoed message.
        byte[] receivedEchoMessage = new byte[length]; // Prepare a buffer for the echoed message.
        in.readFully(receivedEchoMessage); // Read the echoed message fully.
        
        // Check if the echoed message matches the sent message.
        if (!Arrays.equals(encryptedMessage, receivedEchoMessage)) {
            throw new IOException("Echoed message does not match the original message.");
        }   
        
        long endTime = System.nanoTime(); // Record the end time.
        return (endTime - startTime) / 1_000_000; // Calculate and return the RTT in milliseconds.
    }

    // Closes the socket and streams.
    public void close() throws IOException {
        if (socket != null) {
            out.close(); // Close the output stream.
            in.close(); // Close the input stream.
            socket.close(); // Close the socket.
        }
    }
}
