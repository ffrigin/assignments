package assignments;

import java.io.*;
import java.net.Socket;
import java.net.InetSocketAddress;
import java.util.Arrays;

public class TCPLatencyClient {
    private String host;
    private int port;
    private Socket socket;
    private DataOutputStream out;
    private DataInputStream in; 
    // Encryption key, initially set and must match the server's initial key
    private long key = 123456789L;
    public static void main(String[] args) {
        try {
            // Change Port and Host here.
            TCPLatencyClient client = new TCPLatencyClient("localhost", 26900);
            //TCPLatencyClient client = new TCPLatencyClient("pi.cs.oswego.edu", 26900);
            //TCPLatencyClient client = new TCPLatencyClient("rho.cs.oswego.edu", 26900);
            //TCPLatencyClient client = new TCPLatencyClient("moxie.cs.oswego.edu", 26900);
            client.connect();
            client.measureRTTAndThroughput();
            client.close();
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    // Constructor: Initializes client with server host and port
    public TCPLatencyClient(String host, int port) {
        this.host = host;
        this.port = port;
    }

    // Establishes connection to the server and initializes streams
    public void connect() throws IOException {
        socket = new Socket(); // Creates a new socket
        // Connects to the server with a specified timeout
        socket.connect(new InetSocketAddress(host, port), 5000);
        // Sets a read timeout for the socket
        socket.setSoTimeout(10000);
        // Initializes the data output stream for sending data
        out = new DataOutputStream(socket.getOutputStream());
        // Initializes the data input stream for receiving data
        in = new DataInputStream(socket.getInputStream());
    }

    // Measures RTT for messages of different sizes
    public void measureRTTAndThroughput() throws IOException {
        // Array of message sizes
        int[] messageSizes = {8, 64, 512};
        // Iterates over each message size, measures RTT, and prints results
        for (int size : messageSizes) {
            byte[] message = generateRandomMessage(size);
            long rtt = measureRTT(message);
            System.out.println("RTT for " + size + " bytes: " + rtt + " ms");
        }
    }

    // Generates a message of a given size with a predictable pattern
    private byte[] generateRandomMessage(int size) {
        byte[] message = new byte[size];
        // Fills the message with bytes following a specific pattern
        for (int i = 0; i < size; i++) {
            message[i] = (byte) (i % 128);
        }
        return message;
    }

    // Measures the round-trip time for a single message
    public long measureRTT(byte[] originalMessage) throws IOException {
        // takes the start time
        long startTime = System.nanoTime();
        // Encrypts the message using the current key
        byte[] encryptedMessage = XOREncryptionService.encryptDecrypt(originalMessage, key);
        // Sends the length and the now encrypted message to the server
        out.writeInt(encryptedMessage.length);
        out.write(encryptedMessage);
        // Updates the key after sending the message
        key = XOREncryptionService.xorShift(key);
        // Receives the echoed message from the server
        int length = in.readInt();
        byte[] receivedEchoMessage = new byte[length];
        in.readFully(receivedEchoMessage);
        // Throws an exception if the echoed and sent message dont match
        if (!Arrays.equals(encryptedMessage, receivedEchoMessage)) {
            throw new IOException("Echoed message does not match the original message.");
        }   
        // takes the end time and calculates the RTT
        long endTime = System.nanoTime();
        // Converts nanoseconds to milliseconds
        return (endTime - startTime) / 1_000_000; 
    }
    // Closes the socket and streams
    public void close() throws IOException {
        if (socket != null) {
            out.close();
            in.close();
            socket.close();
        }
    }
}
