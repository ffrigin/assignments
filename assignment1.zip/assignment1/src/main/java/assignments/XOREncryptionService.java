package assignments;

public class XOREncryptionService {
    public static long xorShift(long r) {
        r ^= r << 13;
        r ^= r >>> 7;
        r ^= r << 17;
        return r;
    }

    public static byte[] encryptDecrypt(byte[] message, long key) {
        byte[] transformed = new byte[message.length];
        for (int i = 0; i < message.length; i++) {
            transformed[i] = (byte) (message[i] ^ (key >> (8 * (i % 8))));
        }
        return transformed;
    }
}
